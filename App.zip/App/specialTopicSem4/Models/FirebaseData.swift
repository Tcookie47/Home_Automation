//
//  FirebaseData.swift
//  specialTopicSem4
//
//  Created by Anantha krishna on 24/03/20.
//  Copyright © 2020 Anantha Krishna. All rights reserved.
//

import Foundation
struct FirebaseData{
    var devicePower:String
    var deviceToggle:String
}
